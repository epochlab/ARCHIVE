# DeepDream

**Project ID:** IqDhav2m

![alt text](https://github.com/epochlab/DeepDream/blob/main/sample.png)

#### Synthesizing visual textures
Abstract: *A network designed to detect patterns in images can also be run in reverse. By adjusting the source image, a given output neuron (e.g. the one for faces or certain animals) can yield a higher confidence score. This can be used for visualizations to understand the emergent structure of the neural network.*

### Packages

`tensorflow-2.x` `numpy` `pillow`

### Requirements
- Both Linux and Windows are supported. Linux is recommended for performance and compatibility reasons.
- 64-bit Python 3.7.9 installation.

### Acknowledgments
[Inceptionism: Going Deeper into Neural Networks](https://ai.googleblog.com/2015/06/inceptionism-going-deeper-into-neural.html) - Google AI Blog (Alexander Mordvintsev, 2015)<br />
