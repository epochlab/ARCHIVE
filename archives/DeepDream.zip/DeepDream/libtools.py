#!/usr/bin/env python3

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from PIL import Image

model_output = lambda model, inputs:model(inputs)

def load_image(path, max_dim=None):
    img = Image.open(path)
    if max_dim:
        img.thumbnail((max_dim, max_dim))
    img = np.array(img, dtype=np.uint8)
    img = np.expand_dims(img, axis=0)
    return img

def deprocess(img):
    img = 255.0 * (img+1.0) / 2.0
    return np.array(img, np.uint8)

def array_to_img(array, deprocessing=False):
    if deprocessing:
        array = deprocess(array)
    if np.ndim(array)>3:
        assert array.shape[0] == 1
        array=array[0]
    return Image.fromarray(array)

def dd_model(model, layer_names):
    model.trainable = False
    outputs = [model.get_layer(name).output for name in layer_names]
    dd_model = Model(inputs=model.input, outputs=outputs)
    return dd_model

def explore_layers(preprocessed_image, layers_contributions, deep_outputs):
    deep_outputs = dd_model(preprocessed_image)
    for layer_name, outputs in zip(layers_contributions, deep_outputs):
        print(layer_name)
        print(outputs.shape)
        print(outputs.numpy().mean())

def calc_loss(activations):
    loss = []
    for activation in activations:
        loss.append(tf.math.reduce_mean(activation))
    return tf.reduce_sum(loss)

def get_loss_and_gradient(model, inputs, total_variation_weight=0):
    with tf.GradientTape() as tape:
        tape.watch(inputs)
        activations = model_output(model, inputs)
        loss = calc_loss(activations)
        loss = loss + total_variation_weight * tf.image.total_variation(inputs)
    grads = tape.gradient(loss, inputs)
    grads /= tf.math.reduce_std(grads) + 1e-8
    return loss, grads

def run_gradient_ascent(model, inputs, epochs=1, steps_per_epoch=1, weight=0.01, total_variation_weight=0):
    img = tf.convert_to_tensor(inputs)
    for i in range(epochs):
        print(f"epoch: {i+1}",end=' ')
        for j in range(steps_per_epoch):
            loss, grads = get_loss_and_gradient(model, img, total_variation_weight)
            img = img + grads * weight
            img = tf.clip_by_value(img, -1.0, 1.0)
            print('=', end='')
        print("\n")
    return img.numpy()

def random_tile(img, maxroll):
    shift = tf.random.uniform(shape=[2], minval=-maxroll, maxval=maxroll, dtype=tf.int32)
    shift_r, shift_d = shift
    img_rolled = tf.roll(img, shift=[shift_r, shift_d], axis=[1,0])
    return shift_r, shift_d, img_rolled

def calc_loss_and_grads_with_tiling(model, inputs, tile_size=512, total_variation_weight=0.004):
    shift_r, shift_d, img_tiled = random_tile(inputs[0], tile_size)
    grads = tf.zeros_like(img_tiled)
    # create a tensor from 0 to rolled_image width with step of tile size
    x_range = tf.range(0, img_tiled.shape[0], tile_size)[:-1]
    # check if x_range is not empty
    if not tf.cast(len(x_range), bool):
        x_range= tf.constant([0])
    # create a tensor from 0 to rolled_image height with step of tile size
    y_range = tf.range(0, img_tiled.shape[1], tile_size)[:-1]
    # check if y_range is not empty
    if not tf.cast(len(y_range), bool):
        y_range=tf.constant([0])
    for x in x_range:
        for y in y_range:
            with tf.GradientTape() as tape:
                tape.watch(img_tiled)
                # here we create tile from rolled image of size=tile_size
                image_tile = tf.expand_dims(img_tiled[x:x+tile_size, y:y+tile_size], axis=0)
                activations = model_output(model, image_tile)
                loss = calc_loss(activations)
                loss = loss + total_variation_weight * tf.image.total_variation(image_tile)
            grads = grads + tape.gradient(loss, img_tiled)
    grads = tf.roll(grads, shift=[-shift_r,-shift_d], axis=[1,0]) #reverse shifting of rolled image
    grads /= tf.math.reduce_std(grads) + 1e-8
    return loss, grads

def run_gradient_ascent_with_octave_tiling(model, inputs, steps_per_octave=100, num_octaves=2, octave_size=1.3, tile_size=512, weight=0.01, total_variation_weight=0.0004):
    img = tf.convert_to_tensor(inputs)
    weight = tf.convert_to_tensor(weight)
    assert len(inputs.shape)<=4 or len(inputs.shape)>=3
    if len(inputs.shape)==3:
        base_shape = img.shape[:-1]
    base_shape = img.shape[1:-1]
    for n in range(num_octaves):
        print(f'Processing Octave: {n+1}')
        new_shape = tuple([int(dim*(octave_size**n)) for dim in base_shape])
        img = tf.image.resize(img,new_shape)
        for step in range(steps_per_octave):
            print('=',end='')
            loss,grads=calc_loss_and_grads_with_tiling(model, img, tile_size, total_variation_weight)
            img = img + grads*weight
            img = tf.clip_by_value(img, -1.0, 1.0)
        print("\n")
    return tf.image.resize(img, base_shape).numpy()
