#!/usr/bin/env python3

from libtools import *

from tensorflow.keras.applications import inception_v3
from tensorflow.keras.models import load_model

OCTAVE_TILING = False

input = '/mnt/vanguard/datasets/The_Incredulity_of_Saint_Thomas_by_Caravaggio.jpg'

image = load_image(input, max_dim=512)
preprocessed_image = inception_v3.preprocess_input(image)

base_model = inception_v3.InceptionV3(weights='imagenet', include_top=False)

layers_contributions = ['mixed3', 'mixed5']
dd_model = dd_model(base_model, layers_contributions)

if OCTAVE_TILING:
    image_array = run_gradient_ascent_with_octave_tiling(dd_model, preprocessed_image, steps_per_octave=20, num_octaves=8, octave_size=1.1, tile_size=512, weight=0.01, total_variation_weight=0)
else:
    image_array = run_gradient_ascent(dd_model, preprocessed_image, epochs=2, steps_per_epoch=100, weight=0.01)

result = array_to_img(image_array, True)
result.save('result.png')
