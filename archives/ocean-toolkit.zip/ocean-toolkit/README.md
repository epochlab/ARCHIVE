# Ocean Toolkit

**Project ID:** hj6AJStx

![alt text](https://github.com/epochlab/ocean-toolkit/blob/main/sample.png)

#### Ocean Spectrum & Evaluation
Abstract: *A series of examples files and pipeline tools to generate and render ocean spectrums. Including non-simulated ocean surfaces and 360° horizon renders with an optically correct vanishing point; ideal for LED projection or ocean plates.*

### Publish
[Composite](https://vimeo.com/641735725) || [Contact Layer Sheet](https://vimeo.com/641895623)

### Requirements

- Both Linux and Windows are supported. Linux is recommended for performance and compatibility reasons.
- SideFX Houdini 18.5
